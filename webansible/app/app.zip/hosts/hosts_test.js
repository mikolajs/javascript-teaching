'use strict';

describe('myApp.hosts module', function() {

  beforeEach(module('myApp.hosts'));

  describe('hosts controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view1Ctrl = $controller('hostsCtrl');
      expect(view1Ctrl).toBeDefined();
    }));

  });
});
