'use strict';

var groupsMockup = [{name:"Klasa",id:23}, {name:"Sala",id:22},{name:"Hala",id:34}];

var hostsMockup = [{id:23, hosts:[{id:234,name:"PC2", ip:"10.0.0.1", firm:"Nie", ping:"23.12.2014 14:30"},
		                        {id:224,name:"PC4", ip:"10.0.0.2", firm:"Nie", ping:"23.12.2014 14:30"},
		                        {id:134,name:"PC3", ip:"10.0.0.3", firm:"Nie", ping:"23.12.2014 14:30"}]},
		                        {id:22, hosts:[{id:232,name:"KOM1", ip:"10.0.2.1", firm:"Nie", ping:"23.12.2014 14:30"},
		       		              {id:230,name:"KOM2", ip:"10.0.2.2", firm:"Nie", ping:"23.12.2014 14:30"},
		       		              {id:204,name:"KOM3", ip:"10.0.2.4", firm:"Nie", ping:"23.12.2014 14:30"}]},
		                        {id:34,  hosts:[{id:284,name:"HAL1", ip:"199.0.0.1", firm:"Tak", ping:"23.12.2014 14:30"},
			                      {id:237,name:"HAL2", ip:"199.0.0.3", firm:"Tak", ping:"23.12.2014 14:30"}]} ];

angular.module('myApp.hosts', ['ngRoute'])
.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/hosts', {
    templateUrl: 'hosts/hosts.html',
    controller: 'hostsCtrl'
  });
}])
.controller('hostsCtrl', function($scope) {
  $scope.openAdd = false;
  $scope.openAdd = false;
  $scope.groups = groupsMockup;
  $scope.hosts = hostsMockup;
  console.log("Pierwsze ID: " + $scope.groups[0].id);
  $scope.activeGroup = $scope.groups[0];

 $scope.test = "TEST";

  $scope.editHostName = "";
  $scope.editHostIp = "";
  $scope.editHostFirm = false;
  $scope.editHostId= -9999;
  $scope.showErrorMessageHost = false;
  $scope.errorMessageHost = "";
  $scope.inputGroupName = "";

  $scope.change = function(){

	}


  /*


  $scope.removeHostFromGroup = function(index){
    if(confirm("Chcesz usunąć z grupy hosta:  " + $rootScope.hosts[index].name + "?")){
      var removeHost = $rootScope.hosts.splice(index,1)[0];
      $scope.hosts.push(removeHost);
    }
  }

  $scope.editHost = function(index){
    var host =  $scope.hostsAvail[index];
    $scope.editHostName = host.name;
    $scope.editHostIp = host.ip;
    $scope.editHostFirm = (host.firm == 'Tak') ;
    $scope.editHostId = host.id;
  }

  $scope.addToGroup = function(index){
    var removeHost = $scope.hostsAvail.splice(index,1)[0];
    $rootScope.hosts.push(removeHost);
    $scope._clearEdit();
  }

  $scope.addHost = function(){
       if(!$scope._isValid()) return;
      var firmTemp = 'Nie';
      if($scope.editHostFirm) firmTemp = 'Tak' ;
       $scope.hostsAvail.push({id:Math.floor(Math.random()*-1000) ,
         name:$scope.editHostName,
        ip:$scope.editHostIp,
        firm:firmTemp,
        ping:"------"});
      $scope._clearEdit();

  }

  $scope.alterHost = function(){
        if(!$scope._isValid()) return;
       for(i in $scope.hostsAvail){
           if($scope.hostsAvail[i].id == $scope.editHostId ){
             $scope.hostsAvail[i].name  = $scope.editHostName;
             $scope.hostsAvail[i].ip = $scope.editHostIp;
             if($scope.editHostFirm) $scope.hostsAvail[i].firm = 'Tak' ;
             else $scope.hostsAvail[i].firm = 'Nie' ;
             $scope._clearEdit();
             return;
           }
         }
      alert("Błąd, nie znaleziono elementu do zmiany");l
    }

  $scope.delHost = function(){
    //if( $scope.editHostId){$scope._clearEdit(); return;}
    if (confirm("Na pewno chcesz usunąć hosta  " + $scope.editHostId + " : " + $scope.editHostName + "?" )) {
       for(i in $scope.hostsAvail){
         if($scope.hostsAvail[i].id == $scope.editHostId ){
         $scope.hostsAvail.splice(i,1);
          $scope._clearEdit();
           return;
           }
         }
      $scope._clearEdit();
    }
  }

  $scope.firmIpInputChanged = function(){
    $scope.editHostFirm = true;
  }


  $scope._clearEdit = function() {
    $scope.editHostName = "";
    $scope.editHostIp = "";
    $scope.editHostFirm = false;
    $scope.editHostId = -9999;
    $scope.showErrorMessageHost = false;
    $scope.errorMessageHost = "";
  }

  $scope._isValid = function() {
    var valid = true;
    if($scope.editHostName.length < 3) {
      $scope.showErrorMessageHost = true;
      $scope.errorMessageHost = "Nazwa musi być dłuższa. ";
      valid = false;
    }
    if($scope.editHostFirm && $scope.editHostIp.length < 3){
      $scope.showErrorMessageHost = true;
      $scope.errorMessageHost += "  Domena/Ip musi być dłuższa.";
      valid = false;
    }
    return valid;
  }

  $scope.add = function() {
		$scope.inputGroupName = "";
		$scope.openEdit = false;
		$scope.openAdd = true;

	}

	$scope.edit = function() {
		$scope.inputGroupName = $scope.activeGroup.name;
		$scope.openAdd = false;
		$scope.openEdit = true;
	}

	$scope.delete = function(){
		if(confirm("Chcesz usunąć grupę " + $scope.activeGroup.name + "?\n" +
				"Wszelkie informacje o grupie zostaną utracone!")) {
			alert("Kasuję");
		}

	}

	$scope.save = function() {
		$scope.activeGroup.name = $scope.inputGroupName;
		$scope.openAdd = false;
	}

	$scope.alter = function() {

		$scope.openEdit = false;
	}

	$scope.close = function(){
		$scope.openAdd = false;
		$scope.openEdit = false;
	}

	$scope.getHosts = function() {

		//alert($rootScope.groupId);
		//mockuped!!!!!
		for(i in hostMockup) if(hostMockup[i].id == $rootScope.groupId) return hostMockup[i].hosts;
	}


	$scope.ajaxSave = function(){

	}
	$scope.ajaxAlter = function(){

	}
	$scope.change();
  */
});
