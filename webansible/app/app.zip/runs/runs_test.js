'use strict';

describe('myApp.runs module', function() {

  beforeEach(module('myApp.runs'));

  describe('runs controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view1Ctrl = $controller('runsCtrl');
      expect(view1Ctrl).toBeDefined();
    }));

  });
});
