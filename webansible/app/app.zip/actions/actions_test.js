'use strict';

describe('myApp.ActionsCtrl module', function() {

  beforeEach(module('myApp.ActionsCtrl'));

  describe('Actions controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view2Ctrl = $controller('ActionsCtrl');
      expect(view2Ctrl).toBeDefined();
    }));

  });
});
